meals = ["pasta", "pizza", "salad"]

for char in meals:
    print(char.capitalize())

print("Bye!")
